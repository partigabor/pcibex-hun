﻿renamed=0
failed=0
while IFS=',' read new_name old_name; do
    old_name=`echo ${old_name}.wav | sed 's/\"//g'`
    new_name=`echo ${new_name}.wav | sed 's/\"//g'`
    if [ -e "$new_name" ]; then
        mv "$new_name" "$old_name"
        echo "$new_name renamed to $old_name"
        renamed=$[$renamed+1]
    else
        echo "$new_name not found!"
        failed=$[$failed+1]
    fi
done < "rename"
echo "success renamed: $renamed"
echo "failed rename: $failed"